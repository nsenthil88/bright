find /hana/backup/EHQ/log/SYSTEMDB/ -type f -mtime +14 -delete
