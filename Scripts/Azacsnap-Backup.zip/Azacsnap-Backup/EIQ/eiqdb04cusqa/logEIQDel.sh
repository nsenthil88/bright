find /hana/backup/EHQ/log/DB_EIQ/ -type f -mtime +14 -delete
