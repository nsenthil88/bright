find /hana/backup/EHQ/log/DB_EQ4/ -type f -mtime +14 -delete
