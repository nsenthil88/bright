find /hana/backup/EHP/log/SYSTEMDB/ -type f -mtime +14 -delete
