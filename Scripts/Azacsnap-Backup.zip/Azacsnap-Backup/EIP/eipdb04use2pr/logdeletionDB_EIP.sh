find /hana/backup/EHP/log/DB_EIP/ -type f -mtime +14 -delete
