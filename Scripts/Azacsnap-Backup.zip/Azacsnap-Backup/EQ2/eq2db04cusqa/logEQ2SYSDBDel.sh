find /hana/backup/EH2/log/SYSTEMDB/ -type f -mtime +14 -delete
