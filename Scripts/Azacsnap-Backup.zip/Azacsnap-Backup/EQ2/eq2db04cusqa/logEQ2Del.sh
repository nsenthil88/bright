find /hana/backup/EH2/log/DB_EQ2/ -type f -mtime +14 -delete
